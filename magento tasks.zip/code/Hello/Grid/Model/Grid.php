<?php


namespace Hello\Grid\Model;

use Hello\Grid\Api\Data\GridInterface;

class Grid extends \Magento\Framework\Model\AbstractModel implements GridInterface
{

    const CACHE_TAG = 'employee_data';

    protected $_cacheTag = 'employee_data';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'employee_data';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Hello\Grid\Model\ResourceModel\Grid');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * Get Title.
     *
     * @return varchar
     */
    public function getName()
    {
        return $this->getData();
    }

    /**
     * Set Title.
     */
    public function setName($Name)
    {
        return $this->setData(TITLE, $Name);
    }

    /**
     * Get getContent.
     *
     * @return varchar
     */
    public function getEmail()
    {
        return $this->getData();
    }

    /**
     * Set Content.
     */
    public function setEmail($Email)
    {
        return $this->setData(self::CONTENT, $Email);
    }

    /**
     * Get PublishDate.
     *
     * @return varchar
     */
    public function getMobile()
    {
        return $this->getData();
    }

    /**
     * Set PublishDate.
     */
    public function setMobile($Mobile)
    {
        return $this->setData(self::PUBLISH_DATE, $Mobile);
    }
}