<?php
namespace Hello\Type\Model;
use Hello\Type\Api\PostRepositoryInterface;
class PostRepository implements PostRepositoryInterface
{
    /**
     * Return Response for Rest api
     *
     * @api
     * @param No params.
     * @return string[]
     */

    public function __construct(array $fruits = [])
    {
        var_dump($fruits);
    }

    public function getList()
    {
        return "Hi Hello";
    }

}