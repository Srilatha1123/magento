<?php
namespace Hello\Rest\Model;
use Hello\Rest\Api\PostRepositoryInterface;
class PostRepository implements PostRepositoryInterface
{
    /**
     * Return Response for Rest api
     *
     * @api
     * @param No params.
     * @return string[]
     */
    public function getList()
    {
        return "Hi Hello Hru";
    }
}