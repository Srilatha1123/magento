<?php

namespace Hello\SriWorld\Api;

use Magento\Framework\Exception\LocalzedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Api\SearchCriteriaInterface;
use Hello\SriWorld\Api\Data\PersonInterface;

interface PersonRepositoryInterface
{
    
    public function getById($id);

    
    public function save(PersonInterface $person);

    
    public function delete(PersonInterface $person);

   
    public function getList(SearchCriteriaInterface $searchCriteria);
    
}