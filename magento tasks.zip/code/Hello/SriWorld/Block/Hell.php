<?php
/**
 *
 * @package     magento2
 * @author      Jayanka Ghosh
 * @license     https://opensource.org/licenses/OSL-3.0 Open Software License v. 3.0 (OSL-3.0)
 * @link        http://jayanka.me/
 */

namespace Hello\SriWorld\Block;


use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Hello\SriWorld\Model\ResourceModel\Car\CollectionFactory as PersonCollectionFactory;
use Hello\SriWorld\Model\PersonFactory;
use Hello\SriWorld\Api\PersonRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Api\FilterBuilder;

class Hell extends \Magento\Framework\View\Element\Template
{
    protected $searchCriteriaBuilder;
    protected $filterBuilder;
    protected $_PersonCollectionFactory = null;
    protected $PersonFactory;
    protected $_PersonRepository;


    public function __construct(
        Context $context,
       PersonCollectionFactory $PersonCollectionFactory,
        PersonRepositoryInterface $PersonRepository,
        FilterBuilder $filterBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
       PersonFactory $PersonFactory,
        array $data = []
    ) {
        $this->PersonFactory = $PersonFactory;
        $this->_PersonRepository=$PersonRepository;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->_PersonCollectionFactory  = $PersonCollectionFactory;
        parent::__construct($context, $data);
    }

    public function getAddCarPostUrl() {

        return $this->getUrl('sriworld/index/sav');
    }
    public function getDeletePostUrl() {

        return $this->getUrl('sriworld/index/del');
    }

    public function getCollection()
    {
        $PersonCollection = $this->_PersonCollectionFactory ->create();
        $PersonCollection->addFieldToSelect('*')->load();
        return $PersonCollection->getItems();
    }
     public function getAllCars()
     {
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $searchCriteriaBuilder= $objectManager->create('Magento\Framework\Api\SearchCriteriaBuilder');
        $searchCriteria=$searchCriteriaBuilder->addFilter('emp_id' ,'%%','like')->create();
        $list=$this->_PersonRepository->getList($searchCriteria);
        return $list->getItems();
     }
}


// use Magento\Framework\View\Element\Template;
// use Hello\SriWorld\Model\ResourceModel\Car\Collection;

// class Hell extends Template
// {
//     /**
//      * @var Collection
//      */
//     private $collection;

//     /**
//      * Hello constructor.
//      * @param Template\Context $context
//      * @param Collection $collection
//      * @param array $data
//      */
//     public function __construct(
//         Template\Context $context,
//         Collection $collection,
//         array $data = []
//     )
//     {
//         parent::__construct($context, $data);
//         $this->collection = $collection;
//     }

//     public function getAllCars() {
//         return $this->collection;
//     }

//     public function getAddCarPostUrl() {
//         return $this->getUrl('sriworld/index/sav');
//     }
//     public function getDeletePostUrl() {
//         return $this->getUrl('sriworld/index/del');
//     }
//     public function getSearchPostUrl() {
//         return $this->getUrl('sriworld/index/search');
// }
// }