<?php

namespace Hello\SriWorld\Model;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;
use Hello\SriWorld\Api\Data\PersonInterface;
use Hello\SriWorld\Model\ResourceModel\Car as ResourceModel;

class Person extends AbstractModel implements PersonInterface,IdentityInterface
{
    const CACHE_TAG = 'my_emp';

    
    protected function _construct() // phpcs:ignore PSR2.Methods.MethodDeclaration
    {
        $this->_init(ResourceModel::class);
    }

    
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getId()
    {
        return $this->getData('emp_id');
    }
  
    public function getManufacturer()
    {
        return $this->getData('manufacturer');
    }
    public function setManufacturer($Manufacturer)
    {
        return $this->setData('manufacturer', $Manufacturer);
       // print_r($d);
    }

    public function getModel()
    {
        return $this->getData('model');
    }
    public function setModel($Model)
    {
        return $this->setData('model', $Model);
    }
    
}

