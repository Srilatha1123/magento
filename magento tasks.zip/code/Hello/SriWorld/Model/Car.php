<?php

namespace Hello\SriWorld\Model;

use Magento\Framework\Model\AbstractModel;
use Hello\SriWorld\Model\ResourceModel\Car as ResourceModel;

class Car extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}