<?php
namespace Hello\SriWorld\Controller\Index;

    use Magento\Framework\App\Action\Action;
    use Magento\Framework\App\Action\Context;
    use Magento\Framework\Exception\CouldNotSaveException;
    use Magento\Framework\Exception\LocalizedException;
    use Magento\Framework\Exception\NoSuchEntityException;
    use Magento\Framework\View\Result\PageFactory;

    use Hello\SriWorld\Api\PersonRepositoryInterface;
    use Hello\SriWorld\Api\Data\PersonInterface;

    class Sav extends Action
    {
    
        protected $_pageFactory;

        protected $_personRepository;
        protected $_personModel;


        public function __construct(
            Context $context,
            PageFactory $pageFactory,
            PersonRepositoryInterface $personRepository,
            PersonInterface $personInterface
        ) {
            $this->_pageFactory = $pageFactory;
            $this->_personRepository=$personRepository;
            $this->_personModel = $personInterface;
            return parent::__construct($context);
        }

        public function execute()
        {
           $data = $this->getRequest()->getParams();
       //   print_r($data);
//exit;
      //  $Id = $data['emp_id'];
       $Manufacturer = $data["manufacturer"];
        $Model= $data["model"];

        $PersonModel = $this->_personModel;
        
        $val= $this->_personModel->setManufacturer($Manufacturer);
        $val= $this->_personModel->setModel($Model);
          

        try {
            /* Use the resource model to save the model in the DB */
            $this->_personRepository->save($this->_personModel);
            $this->messageManager->addSuccessMessage("Car saved successfully!");
        } catch (\Exception $exception) {
            $this->messageManager->addErrorMessage(__("Error saving car"));
        }

        /* Redirect back to cars page */
        $redirect = $this->resultRedirectFactory->create();
        $redirect->setPath('sriworld');
        return $redirect;
    }
    
}