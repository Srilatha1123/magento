<?php
namespace Hello\SriWorld\Controller\Index;

    use Magento\Framework\App\Action\Action;
    use Magento\Framework\App\Action\Context;
    use Magento\Framework\Exception\CouldNotSaveException;
    use Magento\Framework\Exception\LocalizedException;
    use Magento\Framework\Exception\NoSuchEntityException;
    use Magento\Framework\View\Result\PageFactory;

    use Hello\SriWorld\Api\PersonRepositoryInterface;
    use Hello\SriWorld\Api\Data\PersonInterface;

    class Del extends Action
    {
        protected $_pageFactory;

        protected $_personRepository;
        protected $_personModel;


        public function __construct(
            Context $context,
            PageFactory $pageFactory,
            PersonRepositoryInterface $personRepository,
            PersonInterface $personInterface
        ) {
            $this->_pageFactory = $pageFactory;
            $this->_personRepository=$personRepository;
            $this->_personModel = $personInterface;
            return parent::__construct($context);
        }
    
        public function execute()
        {
            $id=$_GET;
            // echo "Hello World!!!";
        
            try {
                $this->_personRepository->deleteById($id);
                // echo "Deleted the record with id = 8" . "<br>" . "Go to database and check.";
            } catch (NoSuchEntityException $e) {
                echo "No such entity exception - " . $e->getMessage();
            } catch (LocalizedException $e) {
                echo "Localized Exception" . $e->getMessage();
            }
            $redirect = $this->resultRedirectFactory->create();
        $redirect->setPath('sriworld');
        return $redirect;
    }
        }
    