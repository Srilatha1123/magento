<?php
namespace Hello\Change\Plugin;
class Product{
    public function afterGetName(\Magento\Catalog\Model\Product $product,$name)
    {
        // $price = $product->getData('price');
        $name="sri "."$name";
        return $name;
    }
}