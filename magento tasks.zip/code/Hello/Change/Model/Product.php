<?php
namespace Hello\Change\Model;
class Product extends \Magento\Catalog\Model\Product {
    public function GetName()
    {
        $name = parent::getName();
        $name="srilatha "."$name";
        return $name;
    }
}